document.getElementById('play-button').addEventListener('click', function () {
    window.location.href = 'front.html';
  });