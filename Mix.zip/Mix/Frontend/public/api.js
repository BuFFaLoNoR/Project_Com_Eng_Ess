
function decodeJWT(token) {
  const base64Url = token.split('.')[1];  // The payload part of the token
  const base64 = base64Url.replace('-', '+').replace('_', '/');  // Convert to valid base64 encoding
  const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));
  
  return JSON.parse(jsonPayload);  // Return the decoded payload as an object
}

// Function to register a new user
// Function to check if the username is already taken
// Function to check if the username is already taken
export function checkUsernameAvailability(username) {
  return fetch('http://localhost:3222/api/check-username', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username }),
  })
  .then(response => response.json())
  .then(data => {
    return !data.exists;  // Return true if username is available, false if taken
  })
  .catch(error => {
    console.error('Error checking username:', error);
    throw error;  // Re-throw error for the calling code to handle
  });
}

// Function to register a new user
export function registerUser(username, password) {
  return fetch('http://localhost:3222/api/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.error) {
      throw new Error(data.error);  // Handle the error from backend
    }
    return data;  // Return the response if registration was successful
  })
  .catch(error => {
    console.error('Error registering user:', error);
    throw error;  // Re-throw error so frontend can handle it
  });
}



// Function to login a user
// Function to login a user
export function loginUser(username, password) {
  return fetch('http://localhost:3222/api/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.token) {
      // If login is successful, store the token in localStorage
      localStorage.setItem('token', data.token);
      return data; // Return data with token
    } else {
      throw new Error('Login failed');
    }
  })
  .catch((error) => {
    console.error('Error logging in:', error);
    throw error; // Throw error so it can be caught in the HTML script
  });
}


// Function to send the score and playerName to the backend
export function sendScoreToBackend(score) {
  const token = localStorage.getItem('token');

  if (!token) {
    console.error('No token found. Please login first.');
    return;
  }

  // Decode the JWT token to get the player's username
  const decodedToken = decodeJWT(token); 
const playerName = decodedToken.username;
 // Use decodeToken function from jwtdecoder.js

  if (playerName) {
    fetch('http://localhost:3222/api/highscores', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`, // Add token to Authorization header
      },
      body: JSON.stringify({ score: score, playerName: playerName }), // Send score and playerName
    })
    .then(response => response.json())
    .then(data => {
      console.log('Score saved:', data);
    })
    .catch((error) => {
      console.error('Error saving score:', error);
    });
  } else {
    console.error('Failed to retrieve player name from token');
  }
}
