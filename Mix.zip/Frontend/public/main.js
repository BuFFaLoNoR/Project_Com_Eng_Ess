document.getElementById('play-button').addEventListener('click', function () {
    window.location.href = 'front.html';
  });

  window.location.href = `main.html?skin=${skin}`;